K2 Perfume Admin Panel

Default Login:
Username: admin
Password: admin123

Upload the admin folder to your GitHub repo
Then redeploy on Netlify.

Admin URL:
yourwebsite.netlify.app/admin/login.html
